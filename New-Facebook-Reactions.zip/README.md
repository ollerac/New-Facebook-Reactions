Facebook Reactions
------------------

A chrome plugin that lets you add some awesome new emotive reactions to the main Facebook news feed.

![reactions demo](https://s3.amazonaws.com/webnet/fb-plugin/react-demo.png)


The Reactins
============

- dislike
- hate
- love
- threaten
- applaud
- stare creepily
- accuse of racism
- offer bribe 
- express doubt
- incite rebellion
- pass joint
- throw tomato


Credit:
=======

This plugin was totally and completely inspired by a webcomic drawn by Reza Farazmand at http://poorlydrawnlines.com/

You can find the original comic here: http://poorlydrawnlines.com/comic/proposed-facebook-buttons/